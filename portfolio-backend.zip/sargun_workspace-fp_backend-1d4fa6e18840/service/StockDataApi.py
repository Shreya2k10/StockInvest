import random
from static.supabaseClient import supabase

class StockDataApiService:

    @staticmethod
    def search_asset(symbol):
        try:
            response = supabase.table('stockdata').select('*').ilike('ticker', f'%{symbol.upper()}%').limit(5).execute()
            if response.data:
                for asset in response.data:
                    asset['price'] = StockDataApiService.apply_price_fluctuation(asset['price'])
            return response.data
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}

    @staticmethod
    def get_assets():
        try:
            response = supabase.table('stockdata').select('*').execute()
            if response.data:
                for asset in response.data:
                    if asset['price'] != 0:
                        fluctuation = StockDataApiService.apply_price_fluctuation(asset['price'])
                        asset['change_percentage'] = round((fluctuation - asset['price']) * 100 / asset['price'], 2)
                        asset['price'] = fluctuation
                    else:
                        asset['price'] = 0
                        asset['change_percentage'] = 0
            return response.data
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}
    
    @staticmethod
    def get_asset(symbol):
        try:
            response = supabase.table('stockdata').select('*').eq('ticker', symbol.upper()).single().execute()
            if response.data:
                response.data['price'] = StockDataApiService.apply_price_fluctuation(response.data['price'])
            return response.data
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}

    @staticmethod
    def get_current_price(symbol):
        try:
            response = supabase.table('stockdata').select('price').eq('ticker', symbol.upper()).single().execute()
            if response.data:
                price = float(response.data['price'])
                fluctuated_price = StockDataApiService.apply_price_fluctuation(price)
                return fluctuated_price
            else:
                return {'Error': 'Symbol not found in the database'}
        
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}

    @staticmethod
    def get_timeseries_details(symbol):
        try:
            response = supabase.table('stockdata').select('timeseries_values').eq('ticker', symbol.upper()).single().execute()
            if response.data and response.data['timeseries_values']:
                return response.data['timeseries_values']
            else:
                return {'Error': 'Timeseries data not found for the symbol'}
        
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}

    @staticmethod
    def get_top_gainers(count=5):
        try:
            response = supabase.table('stockdata').select('name','ticker', 'price', 'change').order('change', desc=True).limit(count).execute()
            if response.data:
                for asset in response.data:
                    asset['price'] = StockDataApiService.apply_price_fluctuation(asset['price'])
            return response.data
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}

    @staticmethod
    def get_top_losers(count=5):
        try:
            response = supabase.table('stockdata').select('name','ticker', 'price', 'change').order('change').limit(count).execute()
            if response.data:
                for asset in response.data:
                    asset['price'] = StockDataApiService.apply_price_fluctuation(asset['price'])
            return response.data
        except Exception as e:
            return {'Error during StockDataApiService call: ': str(e)}

    @staticmethod
    def apply_price_fluctuation(price):
        fluctuation_percentage = random.uniform(-0.05, 0.05) 
        fluctuated_price = price * (1 + fluctuation_percentage)
        return round(fluctuated_price, 2)
