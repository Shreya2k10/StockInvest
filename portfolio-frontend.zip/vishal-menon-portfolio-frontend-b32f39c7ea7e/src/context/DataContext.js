import React, { createContext, useState, useEffect, useCallback } from 'react';
import axios from '../api/axios';
import { toast } from 'sonner';

export const DataContext = createContext();

function createData(id, datetime, stock_name, type, price, quantity, total) {
    return {
      id,
      datetime,
      stock_name,
      type,
      price,
      quantity,
      total
    };
  }

function createMarketData(id, stock_name, ticker, price, daily_percent, action) {
    return {
      id,
      stock_name,
      ticker,
      price,
      daily_percent,
      action
    };
}

const DataProvider = ({ children }) => {
  const [transactions, setTransactions] = useState([]);
  const [refresh, setRefresh] = useState(false);
  const [market, setMarket] = useState([]);
  const [folioDetails, setFolioDetails] = useState([]);
  const [holdings, setHoldings] = useState([]);
  const [netWorthGraphData, setNetWorthGraphData] = useState();
  const [pieData, setPieData] = useState();
  const [assetData, setAssetData] = useState();
  const [gainers, setGainers] = useState();
  const [losers, setLosers] = useState();
  const [walletData, setWalletData] = useState();
  const [searchVal, setSearchVal] = useState(0);

  useEffect(() => {
    // Fetch data from backend
    const fetchData = async () => {

      //wallet
      try{
        const walletresponse = await axios.get(`/balance`)
        const wallet = walletresponse.data.Balance;
        setWalletData(wallet)
      }catch{
        //toast.error("Error retrieving wallet data.")
      }

      try{
        //user holding top gain loss
        const userGainLoss = await axios.get(`dashboard/user-holdings`)
        const userGainLossData = userGainLoss.data
        
        const holdingData = userGainLossData.asset_wise
        const gainersData = userGainLossData.top_gainers
        const losersData = userGainLossData.top_losers

        setHoldings(holdingData)
        setGainers(gainersData)
        setLosers(losersData)
      }catch{
       // toast.error("Error retrieving user holding data.")
      }

      try{
        //assets
        const assetResponse = await axios.get('assets')
        const allAssetData = assetResponse.data
        setAssetData(allAssetData);
        setSearchVal(searchVal+1);
        
      }catch{
       // toast.error("Error retrieving market data.")
      }

      try{
        //piechart graph
        const PieChartResponse = await axios.get('dashboard/holdings-diversification')
        const outputPieData = Object.entries(PieChartResponse.data).map(([name, value]) => ({
          name,  // The key becomes the 'name' field
          value  // The value remains the 'value' field
        }));
        setPieData(outputPieData)
      }catch{
      //  toast.error("Error retrieving allocation(piechart) data.")
      }

      try{
         //networth graph
         const netWorthGraphResponse = await axios.get('dashboard/networth-history')
         const netGraphData = netWorthGraphResponse.data.map((snap)=>{
 
           return {
             time : snap.timestamp,
             value : snap.networth
           }
         });
         setNetWorthGraphData(netGraphData);
      }catch{
       // toast.error("Error retrieving networth graph data.")
      }

      try{
        //Porfolio Details
        const folioResponse = await axios.get('dashboard/portfolio-details');
        const folioData = folioResponse.data
        setFolioDetails(folioData);
      }catch{
       // toast.error("Error retrieving portfolio data.")
      }

      //transactions
      try{
        const response = await axios.get('transactions');
        const data = response.data.map((transaction) => {

            return createData(
              transaction.id,
              Date(transaction.createdat).toString().slice(0, 24),
              transaction.assetname,
              transaction.action,
              transaction.price,
              transaction.quantity,
              (transaction.price * transaction.quantity).toFixed(2)
            );
          }).reverse();
          setTransactions(data);
      }catch{
        //toast.error("Error retrieving transaction data.")
      }


      try {
          //Market Details

          const MarketResponse = await axios.get('assets/top-gainers');
          console.log(MarketResponse)

          const marketdata = MarketResponse.data.map((asset, index)=>{

            return createMarketData(
              index+1,
              asset.name,
              asset.ticker,
              asset.price,
              asset.change,
              ""
            );
          });
          setMarket(marketdata);
          
      } catch (error) {
        console.error('Error fetching market data:', error);
      }
    };

    fetchData();
  }, [refresh]);

  const forceRefresh = useCallback(() => {
    setRefresh(prev => !prev); // Toggle refresh state to trigger useEffect
    }, []);

  return (
    <DataContext.Provider value={{ searchVal, setSearchVal, walletData, transactions, market, folioDetails, holdings, netWorthGraphData, pieData, assetData, gainers, losers, setTransactions, forceRefresh }}>
      {children}
    </DataContext.Provider>
  );
};

export default DataProvider;
