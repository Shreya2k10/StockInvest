// .svgrrc.js
module.exports = {
    dimensions: false,
  };