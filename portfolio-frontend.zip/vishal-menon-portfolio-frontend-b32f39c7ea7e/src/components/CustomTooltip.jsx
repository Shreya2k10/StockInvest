const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="custom-tooltip" style={{ backgroundColor: '#fff', border: '1px solid #ccc', padding: '10px' }}>
          <p className="label" style={{ margin: 0 }}>{`${payload[0].name} : ${payload[0].value}%`}</p>
        </div>
      );
    }
  
    return null;
  };

export default CustomTooltip;