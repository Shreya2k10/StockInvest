
import { ArrowRight, ArrowLeft } from "lucide-react";
import React, { useEffect } from "react";
import { useState } from "react";

const MyCarousel = (props) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(()=>{
    setCurrentIndex(props.currIndex);
  },[props.currIndex])

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < props.cards.length - 2) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="flex-1">
      <div
        className="flex flex-row transition-transform duration-500"
        style={{
          transform: `translateX(-${currentIndex * (100 / props.cards?.length)}%)`,
        }}
      >
        {props.cards?.map((card, index) => (
          <div key={index} className="">
            {card}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyCarousel;
