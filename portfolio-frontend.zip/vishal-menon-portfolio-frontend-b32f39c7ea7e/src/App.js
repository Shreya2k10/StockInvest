import logo from './logo.svg';
import './App.css';
import { Routes, Route, BrowserRouter, createBrowserRouter, createRoutesFromElements, RouterProvider } from 'react-router-dom'
import Sidenav, { SidebarItem } from './components/Sidenav';
import Market from './pages/Market';
import Portfolio from './pages/Portfolio'
import Analysis from './pages/Analysis'
import Tradehistory from './pages/Tradehistory'
import GeneralCard from './components/GeneralCard';
import { LayoutDashboard, Sidebar } from 'lucide-react';
import SecuritiesCard from './components/SecuritiesCard';
import Wallet from './components/Wallet';
import BuySellModal from './components/BuySellModal';
import { useEffect, useContext } from 'react';
import { DataContext } from './context/DataContext';
import MarketCard from './components/MarketCard';
import StockDetails from './pages/StockDetails';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Sidenav/>}>
      <Route path="market" element={<Market/>}/>
      <Route path="analysis" element={<Analysis/>}/>
      <Route path="tradehistory" element={<Tradehistory/>}/>
      <Route path="portfolio" element={<Portfolio/>}/>
      <Route path="generalcard" element={<GeneralCard/>}/>
      <Route path="securitiescard" element={<SecuritiesCard/>}/>
      <Route path="walletcard" element={<Wallet/>}/>
      <Route path="modal" element={<BuySellModal/>}/>
      <Route path="marketcard" element={<MarketCard/>}/>
      <Route path="stockdetails" element={<StockDetails/>}/>
    </Route>
  )
);

function App() {

  const { forceRefresh } = useContext(DataContext);

  useEffect(()=>{
  //Implementing the setInterval method
  const interval = setInterval(() => {
    forceRefresh();

  }, 10000);

  //Clearing the interval
   return () => clearInterval(interval);
  
    
  },[forceRefresh]);


  return (
    <RouterProvider router={router}/>
  );
}

export default App;
