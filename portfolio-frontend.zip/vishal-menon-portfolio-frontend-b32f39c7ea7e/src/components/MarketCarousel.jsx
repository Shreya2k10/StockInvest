import React, { useEffect } from 'react'
import MyCarousel from './MyCarousel'
import SecuritiesCard from './SecuritiesCard';
import MarketCard from './MarketCard';
import { useState } from 'react';

const MarketCarousel = (props) => {

  // const cards = [
  //   <SecuritiesCard onButtonClick={props.onButtonClick}/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  // // Add more cards as needed
  // ];

  // const card = props.data.map((asset)=>{
  //   <SecuritiesCard/>
  // });

  const [cards, setCards] = useState([]);

  useEffect(()=>{
    setCards(Array.isArray(props.data) ? props.data?.map((asset, index) => (
      <MarketCard
        key={index} // Use a unique key for each card
        asset={asset} // Pass the asset as a prop to SecuritiesCard
        onButtonClick={props.onButtonClick} // Pass the onButtonClick prop if needed
      />
    )) : [] )
  },[props.data,props.onButtonClick])
  

  return (
    <div className='mx-8 mb-5 flex flex-row w-full max-w-[80vw] overflow-hidden'><MyCarousel currIndex={props.currIndex} cards={cards}/></div>
  )
}

export default MarketCarousel