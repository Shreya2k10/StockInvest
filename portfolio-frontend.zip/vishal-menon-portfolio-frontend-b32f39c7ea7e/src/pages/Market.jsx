import React from 'react'
import SimpleSlider from '../components/SimpleSlider'
import Carousel from '../components/Carousel'
import SecuritiesCard from '../components/SecuritiesCard';
import MarketTable from '../components/MarketTable';
import { Divider } from '@mui/material';
import { useContext } from 'react';
import { DataContext } from '../context/DataContext';
import { useEffect, useState } from 'react';
import BuySellModal from '../components/BuySellModal';
import MarketCarousel from '../components/MarketCarousel';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import SlidingStocks from '../components/SlidingStocks';
import { ModalContext } from '../context/ModalProvider';
import StockDetails from './StockDetails';
import { Search } from 'lucide-react';
import SearchBar from '../components/SearchBar';

const Market = () => {

  const {assetData, setSearchVal, searchVal } = useContext(DataContext);
  const { symbol, openModal } = useContext(ModalContext);
  const [num, setNum] = useState(0);

  const [searchValue, setSearchValue] = useState('');
  const [modifiedMarket, setModifiedMarket] = useState();

  const handleSearchValue = (event) => {
    setSearchValue(event.target.value);
    //setSearchVal(event.target.value)
};

  useEffect(()=>{
    if(assetData)
    setModifiedMarket(Array.isArray(assetData) ? assetData?.filter(item => 
      Object.values(item).some(value =>
        String(value).toLowerCase().includes(searchValue.toLowerCase())
      )) : []);
      setNum(num+1);
  },[searchValue, assetData])

  const [modal, setModal] = useState(false);
  const [asset, setAsset] = useState();

  const [featuredIndex, setFeaturedIndex] = useState(0);

  const handlePrev = () => {

      if (featuredIndex > 0) {
        setFeaturedIndex(featuredIndex - 1);
      }
   
  };

  const handleNext = () => {

    if (featuredIndex < assetData?.length- 4) {
      setFeaturedIndex(featuredIndex + 1);
    }
      
  };


  const handleModalOpen = (aname) => {
    if(!modal)
      setAsset(aname)
    setModal(!modal);
  };

  // useEffect(()=>{

  // //   //Implementing the setInterval method
  // // const interval = setInterval(() => {
  // //   forceRefresh();

  // // }, 5000);

  // // //forceRefresh();

  // // setTimeout(() => {
  // //   setSeed(Math.random());
  // // }, 1000);

  // // //Clearing the interval
  // //  return () => clearInterval(interval);
    
  // },[forceRefresh]);

  return (
    <div className='w-[100%] flex flex-col overscroll-x-none'>
      <div className='w-[100%] h-20 flex flex-row justify-center items-center'>
      {/* <img alt="placeholder" src="SlideScroll.png"/> */}
      <SlidingStocks />
      {/* <h1 className='text-xl font-bold'> Sliding/Scrolling Market Movers (dashboard.io) </h1> */}
      </div>
      <Divider/>
      <div className='w-[100%] flex flex-row justify-center items-center'>
      {/* <img alt="placeholder" src="explorestocks.png" className='h-[15rem]'/> */}
      {/* <h1 className='text-xl font-bold'> Featured List </h1> */}



            <div className="glass-effect pt-4 rounded-lg shadow-md bg-[#f5f4fa]">
            <div className='flex flex-row justify-between pr-5'>

            <div className="flex flex-row gap-3 ml-4 ">
              <h1 className="text-2xl md:text-[2rem] font-bold">Explore Stocks</h1>
            </div>
            <div className="flex gap-2">
            <button
            className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
            onClick={() => handlePrev()}
            >
            <ArrowLeft />
            </button>
            <button
            className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
            onClick={() => handleNext()}
            >
            <ArrowRight />
            </button>
            </div>

            </div>

            <MarketCarousel data={assetData} currIndex={featuredIndex} onButtonClick={handleModalOpen}/>
            </div>

      </div>
      <Divider/>
      
      <div className='w-[100%] h-20 flex flex-row justify-center items-center gap-2'>
      {/* <img alt="placeholder" src="placeholder.png" className='h-[15rem]'/> */}
      
      <div className="flex items-center w-full max-w-2xl mx-auto bg-white rounded-full shadow-md overflow-hidden">
      <input
        className="w-full px-4 py-2 text-gray-700 focus:outline-none"
        type="text"
        placeholder="Search..."
        value={searchValue}
        onChange={handleSearchValue}
      />
      <button
        className="p-2 text-gray-500 hover:text-gray-700 focus:outline-none"
      >
        <Search className="w-5 h-5" />
      </button>
      </div>
    
      {/* <input className='p-2 rounded w-[25rem] border shadow-generalcard' value={searchValue} onChange={handleSearchValue}></input> */}
      {/* <h1 className='text-xl font-bold'> Search </h1> */}
       </div>
       {/* <div className='w-[100%] h-10 flex flex-row justify-center items-center'></div> */}
      <Divider/> 
      <div className='w-[100%] flex flex-row justify-center items-center'>
      {/* <h1 className='text-xl font-bold'> Table with Market Data (buy/sell here) </h1> */}
      <MarketTable onButtonClick={handleModalOpen} data={modifiedMarket} key={num}/>
      </div>
      <Divider/>
      {
      modal && <BuySellModal defaultBuy={true} asset={asset} onButtonClick={handleModalOpen}/>
      }
      {
      (openModal) && <StockDetails symbol={symbol}/>
      }
    </div>  
  )
}

export default Market