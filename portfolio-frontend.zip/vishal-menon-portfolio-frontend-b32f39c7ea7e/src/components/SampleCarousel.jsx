import React from 'react'
import MyCarousel from './MyCarousel'
import SecuritiesCard from './SecuritiesCard';

const SampleCarousel = (props) => {

  // const cards = [
  //   <SecuritiesCard onButtonClick={props.onButtonClick}/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  //   <SecuritiesCard/>,
  // // Add more cards as needed
  // ];

  // const card = props.data.map((asset)=>{
  //   <SecuritiesCard/>
  // });
  
  const cards =  (Array.isArray(props.data) ? props.data?.filter(asset => parseInt(asset.quantity) >= 1).map((asset, index) => (
    <SecuritiesCard
      key={index} // Use a unique key for each card
      asset={asset} // Pass the asset as a prop to SecuritiesCard
      onButtonClick={props.onButtonClick} // Pass the onButtonClick prop if needed
    />
  )) : [] );


  return (
    <div className='mx-8 mb-5 flex flex-row w-full max-w-[60vw] overflow-hidden'><MyCarousel currIndex={props.currIndex} cards={cards}/></div>
  )
}

export default SampleCarousel