from static.supabaseClient import supabase
from model.IndividualHoldingsResponse import IndividualHoldingsResponse
from service.StockDataApi import *
import time , threading
from queue import Queue
from datetime import datetime

NETWORTH_HISTORY = Queue(maxsize=40) # to store networth values

def get_assetwise_holding_data(): 
    holdings_data = supabase.table('holdings').select('assetname', 'quantity_holded', 'ticker','average_price').execute().data
    holdingwise_response = []
    
    for asset in holdings_data:
        holding = IndividualHoldingsResponse()
        holding.asset_name = asset['assetname']
        holding.ticker = asset['ticker']
        holding.quantity = asset['quantity_holded']

        holding.current_price = StockDataApiService.get_current_price(asset['ticker'])
        holding.average_price = asset['average_price']
        holding.total_invested = round(asset['quantity_holded'] * asset['average_price'], 2)
        
        if holding.total_invested != 0:
            holding.pnl_percent = round((holding.current_price * asset['quantity_holded'] - holding.total_invested) * 100 / holding.total_invested, 2)
        
        holdingwise_response.append(holding.to_dict())

    return holdingwise_response

def calculate_networth():
    holdings_data = supabase.table('holdings').select('quantity_holded', 'ticker').execute().data
    networth = 0.0
    for holding in holdings_data:
        current_price = StockDataApiService.get_current_price(holding['ticker'])
        networth += (current_price * holding['quantity_holded'])
    return networth

def update_networth_history():
    while True:
        try:
            current_networth = calculate_networth()
            timestamp = datetime.now().strftime('%H:%M:%S')
            if NETWORTH_HISTORY.full():
                NETWORTH_HISTORY.get()
            NETWORTH_HISTORY.put({'timestamp': timestamp, 'networth': round(current_networth,2)})
        except Exception as e:
            print(f"Error updating net worth history: {e}")
        time.sleep(20)

def start_networth_logging():
    new_thread = threading.Thread(target=update_networth_history, daemon=True)
    new_thread.start()