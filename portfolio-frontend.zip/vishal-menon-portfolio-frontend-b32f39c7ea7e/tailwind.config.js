/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      keyframes: {
        ticker: {
          '0%': { transform: 'translateX(100%)' },
          '100%': { transform: 'translateX(-100%)' },
        },
      },
      animation: {
        ticker: 'ticker 30s linear infinite',
      },
      boxShadow: {
        'generalcard': '0px 17.538px 61.385px 0px rgba(86, 128, 146, 0.5)',
        'generalcard2' : 'rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px',
        'generalcard3': 'rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px',
        'walletrect': '0px -20.028px 20.028px 0px rgba(254, 81, 150, 0.15), 0px 20.028px 20.028px 0px rgba(255, 255, 255, 0.15)'
      },
      colors: {
        'wallet-rect': '#FFD7FB',
      },
      fontFamily: {
        poppins: ["Poppins", "sans-serif"],
        inter: ["Inter", "sans-serif"]
      },
      backgroundImage: {
        'wallet': 'linear-gradient(108deg, #D0F2F4 2.44%, rgba(247, 232, 254, 0.98) 97.81%)',
      },
      backdropBlur: {
        'walletblur': '30.04158592224121px',
        'walletrect': '4.005544662475586px'
      },
      blur: {
        'custom': '11.01524829864502px',
      }
    },
  },
  plugins: [],
}

