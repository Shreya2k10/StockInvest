# supabase_client.py
from supabase import create_client, Client

from static.config import SUPABASE_URL, SUPABASE_KEY

url: str = SUPABASE_URL
key: str = SUPABASE_KEY
supabase: Client = create_client(url, key)
