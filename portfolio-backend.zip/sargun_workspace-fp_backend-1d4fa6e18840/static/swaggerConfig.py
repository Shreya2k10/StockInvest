swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'PortfolioManagementAPI',
            "route": '/pm_api.json',
            "rule_filter": lambda rule: True,
            "model_filter": lambda tag: True,
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/swagger/"
}

swagger_template = {
    "info": {
        "title": "Portfolio Management API",
        "version": "1.0.0",
    }
}