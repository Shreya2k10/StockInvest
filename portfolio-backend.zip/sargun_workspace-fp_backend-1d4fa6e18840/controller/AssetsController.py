from service.StockDataApi import *
from service.YahooFinanceApi import *
from flask import Blueprint, request, jsonify
from flasgger import Swagger, swag_from

assets_bp = Blueprint('asset', __name__)

@assets_bp.route('/assets/', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'responses': {
        200: {
            'description': 'Returns list of assets.',
        }
    }
})
def get_assets():
    assets = StockDataApiService.get_assets()
    return jsonify(assets), 200


@assets_bp.route('/assets/search/<symbol>', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'parameters': [
        {
            'name': 'symbol',
            'in': 'path',
            'type': 'string',
            'required': True,
        }
    ],
    'responses': {
        200: {
            'description': 'Returns asset details of the searched symbol',
        },
        404: {
            'description': 'Asset Details not found.',
            'examples': {
                'application/json': {"message": "Asset Details not found"}
            }
        }
    }
})
def search_asset(symbol):
    asset = StockDataApiService.search_asset(symbol)
    return jsonify(asset), 200


@assets_bp.route('/assets/<symbol>', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'parameters': [
        {
            'name': 'symbol',
            'in': 'path',
            'type': 'string',
            'required': True,
        }
    ],
    'responses': {
        200: {
            'description': 'Returns asset details of the selected symbol',
        },
        404: {
            'description': 'Asset Details not found.',
            'examples': {
                'application/json': {"message": "Asset Details not found"}
            }
        }
    }
})
def get_asset(symbol):
    asset = StockDataApiService.get_asset(symbol)
    return jsonify(asset), 200


@assets_bp.route('/assets/timeseries/<symbol>', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'parameters': [
        {
            'name': 'symbol',
            'in': 'path',
            'type': 'string',
            'required': True,
        }
    ],
    'responses': {
        200: {
            'description': 'Returns asset details of the selected symbol with timeseries data',
        },
        404: {
            'description': 'Asset Details not found.',
            'examples': {
                'application/json': {"message": "Asset Details not found"}
            }
        }
    }
})
def get_timeseries_details(symbol):
    asset = StockDataApiService.get_timeseries_details(symbol)
    return jsonify(asset), 200


@assets_bp.route('/assets/top-gainers', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'responses': {
        200: {
            'description': 'Returns list of Market top gainers.',
        }
    }
})
def get_top_gainers():
    assets = StockDataApiService.get_top_gainers()
    return jsonify(assets), 200


@assets_bp.route('/assets/top-losers', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'responses': {
        200: {
            'description': 'Returns list of Market top losers.',
        }
    }
})
def get_top_losers():
    assets = StockDataApiService.get_top_losers()
    return jsonify(assets), 200


@assets_bp.route('/assets/company-details/<symbol>', methods=['GET'])
@swag_from({
    'tags': ['Assets'],
    'parameters': [
        {
            'name': 'symbol',
            'in': 'path',
            'type': 'string',
            'required': True,
        }
    ],
    'responses': {
        200: {
            'description': 'Returns company details of the selected symbol',
        },
        404: {
            'description': 'Company Details not found.',
            'examples': {
                'application/json': {"message": "Company Details not found"}
            }
        }
    }
})
def get_company_details(symbol):
    asset = YahooFinanceApiService.get_company_details(symbol)
    return jsonify(asset), 200