import React from 'react'
import { Button } from '@mui/material'
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { green, orange } from '@mui/material/colors';

const theme = createTheme({
  palette: {
    custom: {
      main: green[500],
      light: green[300],
      dark: green[700],
      contrastText: '#fff',
    },
  },
});

const SecuritiesCard = (props) => {

  const giveAssetName = () => {
    props.onButtonClick(props.asset)
  }

  return (
    <div className='mx-3 mt-3 mb-5'>
    <div className='flex flex-col h-[10rem] w-[20rem] bg-white border rounded-xl shadow-generalcard3'>
        {/* First line */}
        <div className='border-b flex flex-row justify-between'>
        <div className='px-2'>
        <h1 className='pt-2 font-bold font-inter'>{props.asset.asset_name}</h1>
        <h2 className='text-sm font-inter'>{props.asset.ticker}</h2>
        </div>
        <ThemeProvider theme={theme}>
        <Button variant="contained" color="custom"    sx={{
          borderTopRightRadius: '8px', // Adjust the radius as needed
          borderBottomRightRadius: '0px',
          borderTopLeftRadius: '0px',
          borderBottomLeftRadius: '0px',
          padding: '4px 4px',
          fontSize: '0.75rem',
          minWidth: 'auto',
          boxShadow: 'none',
          '&:hover': {
            boxShadow: 'none' // Remove box shadow on hover
          }
        }}
        onClick={giveAssetName}
        >Sell Asset</Button>
        </ThemeProvider>
        </div>

        <div className='h-full flex flex-col justify-center items-center '>
        <h2 className='font-inter font-bold text-xl text-[#000000]'>$ {(props.asset.current_price * props.asset.quantity).toFixed(2)}</h2>
        <h2 className='font-inter text-sm text-[#000000]'>Quantity: {props.asset.quantity}</h2>
        <h2 className={`font-inter font-bold ${(parseFloat(props.asset.pnl_percent) > 0) ? 'text-[#34C759]' : 'text-red-300' } `}>{props.asset.pnl_percent ? "(" +props.asset.pnl_percent + "%)" : "---"}</h2>
        </div>
        
        
    </div>
    </div>
  )
}

export default SecuritiesCard