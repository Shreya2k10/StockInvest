import React, { useEffect } from 'react'
import EnhancedTable from '../components/EnhancedTable'
import { DataContext } from '../context/DataContext';
import { useContext, useState } from 'react';

const Tradehistory = () => {

  const { transactions, forceRefresh } = useContext(DataContext);
  const [seed, setSeed] = useState(1);

  useEffect(()=>{

  //   //Implementing the setInterval method
  // const interval = setInterval(() => {
  //   forceRefresh();
  //   setSeed(Math.random());
  // }, 5000);

  // //forceRefresh();

  // setTimeout(() => {
  //   setSeed(Math.random());
  // }, 1000);

  //Clearing the interval
    // return () => clearInterval(interval);
    
  },[forceRefresh]);

  return (
    <div>
    <div className='px-10 pt-5 w-full flex flex-row justify-center flex-wrap	'>
    <h1 className='text-[2rem] font-bold mt-5 mb-10'>Transactions</h1>
    <EnhancedTable data={transactions} key={seed}/>
    </div>
    </div>
  )
}

export default Tradehistory