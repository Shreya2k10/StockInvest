from flask import Blueprint, request, jsonify
from flasgger import Swagger, swag_from
from static.supabaseClient import supabase
from utility.BalanceUtility import *

balance_bp = Blueprint('balance', __name__)

@balance_bp.route('/balance/add/<amount>', methods=['POST'])
@swag_from({
    'tags': ['Balance'],
    'summary': 'Adds balance to the wallet',
    'description': 'This endpoint will take an (amount:double) as the parameter and update the balance in the database.',
    'parameters': [
        {
            'name': 'amount',
            'in': 'path',
            'type': 'number',
            'required': True,
        }
    ],
    'responses': {
        '200': {
            'description': 'Balance updated successfully',
            'schema': {
                'type': 'object',
                'properties': {
                    'balance': {
                        'type': 'number',
                        'format': 'double'
                    }
                }
            }
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def add_balance(amount):
    try:
        if float(amount) <= 0.0:
            return jsonify({"message": 'Entered invalid amount value'}), 400
         
        table = supabase.table("walletbalance")
        record = (table
                  .select("*")
                  .execute())
        if len(record.data) == 1:
            originalAmount = (record.data[0]['balance'])
            updated_amount = originalAmount + float(amount)
            return set_balance(table, updated_amount)
        else:
            response = table.insert({"balance": amount}).execute()
            return jsonify({"message": 'Balance added Successfully'}), 200

    except Exception as exception:
        print("Exception:", exception)
        return jsonify({"error": "Internal server error"}), 500


@balance_bp.route('/balance/', methods=['GET'])
@swag_from({
    'tags': ['Balance'],
    'summary': 'Returns balance of the wallet',
    'description': 'This endpoint Returns balance of the wallet.',
    'responses': {
        '200': {
            'description': '{ \"Balance\" : xyz }'
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def display_balance():
    try:
        table = supabase.table("walletbalance")
        record = table.select("*").execute()
        walletBalance = 0.0
        if len(record.data) == 1:
            walletBalance = record.data[0]['balance']

        return jsonify({"Balance": walletBalance}), 200
    
    except Exception as exception:
        return jsonify({"error": "Internal server error"}), 500


