import React from 'react'
import MoneyIcon from './icons/MoneyIcon'

const GeneralCard = (props) => {
  return (
    <div className=''>
    <div className='w-[15rem] h-[8rem] rounded-2xl border hover:bg-slate-100 transition-colors duration-900 shadow-generalcard3 flex flex-row gap-4 justify-center items-center'>
        
        <img alt="" className='w-10' src="moneypic.png"/>
        <div className='h-full py-6 flex flex-col justify-between items-center '>
        <h2 className='font-inter font-bold text-slate-900'>{props.heading}</h2>
        <h2 className='font-inter font-bold text-2xl text-[#407EC8]'>{props.value}</h2>
        <h2 className={`font-inter font-bold ${(parseFloat(props.percent) > 0) ? 'text-[#34C759]' : 'text-red-300' } `}>{props.percent ? props.percent + "%" : "---"}</h2>
        </div>
    </div>
    </div>
  )
}

export default GeneralCard