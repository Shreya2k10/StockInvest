import * as React from "react"
const MoneyIcon = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={48}
    height={48}
    fill="none"
    {...props}
  >
    <circle cx={24.168} cy={24} r={23.238} fill="url(#a)" />
    <path
      stroke="#fff"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2.631}
      d="M32.694 21.418h-12.18a2.436 2.436 0 0 0-2.436 2.436v7.308a2.436 2.436 0 0 0 2.436 2.435h12.18a2.436 2.436 0 0 0 2.436-2.435v-7.308a2.436 2.436 0 0 0-2.436-2.436Z"
    />
    <path
      stroke="#fff"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2.631}
      d="M30.258 21.418v-2.436a2.436 2.436 0 0 0-2.436-2.436h-12.18a2.436 2.436 0 0 0-2.435 2.436v7.308a2.436 2.436 0 0 0 2.435 2.436h2.436"
    />
    <path
      stroke="#fff"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={1.491}
      d="M27.997 25.973a1.11 1.11 0 0 0-.445-.383 1.306 1.306 0 0 0-.607-.128h-1.17c-.31 0-.607.107-.826.3a.963.963 0 0 0-.342.723c0 .27.123.531.342.723.22.192.517.3.827.3h1.169c.31 0 .607.108.827.3.22.191.342.451.342.723a.963.963 0 0 1-.342.723c-.22.192-.517.3-.827.3h-1.17a1.305 1.305 0 0 1-.606-.128 1.112 1.112 0 0 1-.445-.384M26.36 29.554v1.023m0-6.139v1.024-1.024Z"
    />
    <defs>
      <linearGradient
        id="a"
        x1={6.191}
        x2={36.529}
        y1={9.531}
        y2={40.223}
        gradientUnits="userSpaceOnUse"
      >
        <stop stopColor="#8353C0" />
        <stop offset={1} stopColor="#C6ABFF" />
      </linearGradient>
    </defs>
  </svg>
)
export default MoneyIcon
