from flask import Flask
from controller.AssetsController import assets_bp
from controller.BalanceController import balance_bp
from controller.TransactionsController import transaction_bp
from controller.DashboardDetailsController import dashboard_details_bp
from controller.StocksGraphsController import stock_graph_details_bp
from flasgger import Swagger
from static.swaggerConfig import swagger_config, swagger_template
from flask_cors import CORS
from utility.HoldingsUtility import start_networth_logging

app = Flask(__name__)
CORS(app)
swagger = Swagger(app, config=swagger_config, template=swagger_template)


app.register_blueprint(assets_bp)
app.register_blueprint(balance_bp)
app.register_blueprint(transaction_bp)
app.register_blueprint(dashboard_details_bp)
app.register_blueprint(stock_graph_details_bp)

start_networth_logging()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
