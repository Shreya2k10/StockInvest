from flask import Blueprint, request, jsonify
from flasgger import swag_from
from static.supabaseClient import supabase
from service.StockDataApi import StockDataApiService
from controller.BalanceController import set_balance
from enums.ActionEnum import Action

transaction_bp = Blueprint('transaction', __name__)


@transaction_bp.route('/transactions/purchase', methods=['POST'])
@swag_from({
    'tags': ['Transaction'],
    'summary': 'Purchase Assets',
    'description': 'This endpoint will take the symbol, price, and quantity as parameters and process the assets purchase.',
    'parameters': [
        {
            'name': 'symbol',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'symbol': {
                        'type': 'string',
                        'example': 'AAPL'
                    },
                    'assetname': {
                        'type': 'string',
                        'example': 'Apple inc'
                    },
                    'price': {
                        'type': 'number',
                        'format': 'double',
                        'example': 150.00
                    },
                    'quantity': {
                        'type': 'integer',
                        'example': 10
                    }
                }
            }
        }
    ],
    'responses': {
        '200': {
            'description': 'Assets purchased successfully',
            'schema': {
                'type': 'object',
                'properties': {
                    'message': {
                        'type': 'string'
                    }
                }
            }
        },
        '400': {
            'description': 'Invalid input'
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def purchase_assets():
    data = request.get_json()
    symbol = data.get('symbol')
    price = round(data.get('price'),2)
    quantity = data.get('quantity')
    asset_name = data.get('assetname')
    
    if not symbol or not price or not quantity or quantity <= 0:
        return jsonify({'error': 'Invalid input data'}), 400

    try:
        asset_info = StockDataApiService.get_asset(symbol)
        # asset Info Validation
        if 'error' in asset_info:
            return jsonify({'error': 'Invalid asset symbol'}), 400


        # Wallet Balance Validation
        wallet = supabase.table("walletbalance").select("*").execute()

        if not wallet.data or len(wallet.data) == 0:
            return jsonify({'error': 'Wallet not found'}), 404
        
        wallet_balance = wallet.data[0]['balance']

        total_cost = round(price * quantity,2)  # this much amount will be required to buy selected assets

        if wallet_balance < total_cost:
            return jsonify({'error': 'Insufficient balance'}), 400


        # Updating wallet's balance
        new_balance = wallet_balance - total_cost
        set_balance(supabase.table("walletbalance"), new_balance)
        
        # Recording transaction
        supabase.table("transaction").insert({
            "ticker":symbol,
            "assetname": asset_name,
            "assettypeid": 1,  # currently doing for stocks only
            "quantity": quantity,
            "action": Action.BUY.value,
            "price": price
        }).execute() 

        #updating holdings
        holdings_record = supabase.table("holdings").select("*").eq("ticker", symbol).execute()
        if len(holdings_record.data) == 1:
            current_values = holdings_record.data[0]
            new_quantity = current_values['quantity_holded'] + quantity 
            new_avg_price = round((current_values['average_price']*current_values['quantity_holded'] + total_cost ) / new_quantity,2)
            response = supabase.table("holdings").update({
                        "quantity_holded": new_quantity,
                        "average_price": new_avg_price
                       }).eq("id", current_values['id']).execute()
        else:
            # Inserting record for 1st time
            response = supabase.table("holdings").insert({
                            "ticker":symbol,
                            "assetname": asset_name,
                            "assettypeid": 1,  # currently doing for stocks only
                            "quantity_holded": quantity,
                            "average_price": price,
                        }).execute()
        return jsonify({'message': "Assets purchased successfully."}), 200

    except Exception as e:
        return jsonify({'error': f"Transaction Failed : {str(e)}"}), 500


@transaction_bp.route('/transactions/sell', methods=['POST'])
@swag_from({
    'tags': ['Transaction'],
    'summary': 'Sell Assets',
    'description': 'This endpoint will take the symbol, price, and quantity as parameters and process the assets sale.',
    'parameters': [
        {
            'name': 'symbol',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'symbol': {
                        'type': 'string',
                        'example': 'AAPL'
                    },
                    'assetname': {
                        'type': 'string',
                        'example': 'Apple Inc'
                    },
                    'price': {
                        'type': 'number',
                        'format': 'double',
                        'example': 150.00
                    },
                    'quantity': {
                        'type': 'integer',
                        'example': 10
                    }
                }
            }
        }
    ],
    'responses': {
        '200': {
            'description': 'Assets sold successfully and Holdings updated successfully',
            'schema': {
                'type': 'object',
                'properties': {
                    'message': {
                        'type': 'string'
                    }
                }
            }
        },
        '400': {
            'description': 'Invalid input'
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def sell_assets():
    data = request.get_json()
    symbol = data.get('symbol')
    price = round(data.get('price'),2)
    quantity = data.get('quantity')
    asset_name = data.get('assetname')

    if not symbol or not price or not quantity or quantity <= 0:
        return jsonify({'error': 'Invalid input data'}), 400

    try:
        asset_info = StockDataApiService.get_asset(symbol)
        # asset Info Validation
        if 'error' in asset_info:
            return jsonify({'error': 'Invalid asset symbol'}), 400

        # Wallet Validation
        wallet = supabase.table("walletbalance").select("*").execute()
        if not wallet.data or len(wallet.data) == 0:
            return jsonify({'error': 'Wallet not found'}), 404
        wallet_balance = wallet.data[0]['balance']


        # Quantity Validation
        holdings_record = supabase.table("holdings").select("*").eq("ticker", symbol).execute()
        current_values = holdings_record.data[0]
        actual_quantity = current_values['quantity_holded']

        if quantity > actual_quantity:
            return jsonify({'error': 'Quantity specified is higher than what you have'}), 404

        # Price Validation
        selling_price = float(price)
        # market_price = StockDataApiService.get_current_price(symbol)
        # if selling_price > float(market_price):
        #     return jsonify({'error': 'The selling price you have set is higher than the current market price. Please lower your selling price and try again.'}), 400


        # Updating wallet's balance
        new_balance = wallet_balance + (selling_price * quantity)
        set_balance(supabase.table("walletbalance"), new_balance)


        # Record the transaction
        supabase.table("transaction").insert({
            "ticker": symbol,
            "assetname": asset_name,
            "assettypeid": 1,  # currently doing for stocks only
            "quantity": quantity,
            "action": Action.SELL.value,
            "price": price
        }).execute()

        #updating holdings
        new_quantity = actual_quantity - quantity
        if new_quantity == 0:
            #need to delete holding
            response = supabase.table("holdings").delete().eq("id", current_values['id']).execute()
            pass
        else:
            new_avg_price = round((current_values['average_price']*current_values['quantity_holded'] - selling_price * quantity ) / new_quantity,2)
            response = supabase.table("holdings").update({
                        "quantity_holded": new_quantity,
                        "average_price": new_avg_price
                       }).eq("id", current_values['id']).execute()
            
        return jsonify({'message': "Asset sold successfully."}), 200

    except Exception as e:
        return jsonify({'error': f"Transaction Failed : {str(e)}"}), 500


@transaction_bp.route('/transactions/',methods=['GET'])
@swag_from({
    'tags': ['Transaction'],
    'summary': 'Transaction History',
    'description': 'This endpoint will give the entire history of users activity',
    'responses': {
        '200': {
            'description': 'Transaction History Retrieved successfully',
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def get_transaction_history():
    try:
        transaction_history = supabase.table("transaction").select(
            'id',
            'ticker',
            'assetname',
            'createdat',
            'quantity',
            'price',
            'action').execute().data
        
        return transaction_history
    except Exception as e:
        return jsonify({'error': f"Failed to fetch transaction details : {str(e)}"}), 500
