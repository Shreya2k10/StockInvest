import React, { useState, useEffect } from 'react'
import GeneralCard from '../components/GeneralCard'
import Divider from '@mui/material/Divider';
import SecuritiesCard from '../components/SecuritiesCard';
import EnhancedTable from '../components/EnhancedTable';
import Wallet from '../components/Wallet';
import Wolf from '../components/icons/Wolf';
import SimpleSlider from '../components/SimpleSlider';
import Analysis from './Analysis';
import SimpleLineChart from '../components/SimpleLineChart';
import SimplePieChart from '../components/SimplePieChart';
import { ExternalLink } from 'lucide-react';
import SampleCarousel from '../components/SampleCarousel';
import BuySellModal from '../components/BuySellModal';
import Profile from '../components/Profile';
import { useContext } from 'react';
import { DataContext } from '../context/DataContext';
import { ArrowLeft,ArrowRight } from 'lucide-react';
import { Toaster, toast } from 'sonner'

const Portfolio = () => {

  const [modal, setModal] = useState(false);
  const [assetname, setAssetname] = useState();
  const { folioDetails, holdings, gainers, losers} = useContext(DataContext);

  const [holdingIndex, setHoldingIndex] = useState(0);
  const [gainersIndex, setGainersIndex] = useState(0);
  const [losersIndex, setLosersIndex] = useState(0);

  const handlePrev = (title) => {

    if(title === "Holding")
    {
      if (holdingIndex > 0) {
        setHoldingIndex(holdingIndex - 1);
      }
    }
    else if (title === "Gainers"){
      if (gainersIndex > 0) {
        setGainersIndex(gainersIndex - 1);
      }
    }
    else if (title === "Losers"){
      if (losersIndex > 0) {
        setLosersIndex(losersIndex - 1);
      }
    }
  };

  const handleNext = (title) => {

    if(title === "Holding")
      {
        if (holdingIndex < holdings?.length - 2) {
          setHoldingIndex(holdingIndex + 1);
        }
      }
      else if (title === "Gainers"){
        if (gainersIndex < holdings?.length - 2) {
          setGainersIndex(gainersIndex + 1);
        }
      }
      else if (title === "Losers"){
        if (losersIndex < holdings?.length - 2) {
          setLosersIndex(losersIndex + 1);
        }
      }

    
  };

  const handleModalOpen = (aname) => {
    if(!modal)
      setAssetname(aname)
    setModal(!modal);
  };

  return (
    <div className="w-full flex flex-col overscroll-x-none">
      <div className="m-4 flex justify-between items-center">
        <Profile/>
        <img alt="logo" className='w-[6rem]' src="logo.png"/>
      </div>
      <Divider/>
      <div className="flex flex-col md:flex-row mt-10">
        <div className="w-full md:w-[69%] flex flex-col md:px-3">
          <div className="flex flex-row justify-center flex-wrap mb-10 gap-2 md:gap-10">
            <GeneralCard value={"$ " +folioDetails?.total_invested?.toFixed(2)} heading="Total Invested" />
            <GeneralCard percent={"$ " +folioDetails?.pnl_percent} value={"$ " +folioDetails?.profit_loss?.toFixed(2) } heading="Profit/Loss" />
            <GeneralCard value={"$ " +folioDetails?.net_worth?.toFixed(2) } heading="Portfolio Value" />
          </div>
          <div className="pt-7 w-full flex flex-col gap-5">
            <div className="glass-effect pt-4 rounded-lg shadow-md bg-[#f5f4fa]">

            <div className='flex flex-row justify-between pr-5'>

              <div className="flex flex-row gap-3 ml-4 ">
                <h1 onClick={()=> toast('testing toast')}className="text-2xl md:text-[2rem] font-bold">Holdings</h1>
              </div>
              <div className="flex gap-2">
              <button
              className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
              onClick={() => handlePrev("Holding")}
              >
              <ArrowLeft />
              </button>
              <button
              className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
              onClick={() => handleNext("Holding")}
              >
              <ArrowRight />
              </button>
              </div>

            </div>
              <SampleCarousel data={holdings} currIndex={holdingIndex} onButtonClick={handleModalOpen}/>
            </div>
            
            <div className="glass-effect pt-4 rounded-lg shadow-md bg-[#f5f4fa]">
            <div className='flex flex-row justify-between pr-5'>

            <div className="flex flex-row gap-3 ml-4 ">
              <h1 className="text-2xl md:text-[2rem] font-bold">Top Gainers</h1>
            </div>
            <div className="flex gap-2">
            <button
            className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
            onClick={() => handlePrev("Gainers")}
            >
            <ArrowLeft />
            </button>
            <button
            className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
            onClick={() => handleNext("Gainers")}
            >
            <ArrowRight />
            </button>
            </div>

            </div>
              <SampleCarousel data={gainers} currIndex={gainersIndex} onButtonClick={handleModalOpen}/>
            </div>

            <div className="glass-effect pt-4 rounded-lg shadow-md bg-[#f5f4fa]">
            <div className='flex flex-row justify-between pr-5'>

            <div className="flex flex-row gap-3 ml-4 ">
              <h1 className="text-2xl md:text-[2rem] font-bold">Top Losers</h1>
            </div>
            <div className="flex gap-2">
            <button
            className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
            onClick={() => handlePrev("Losers")}
            >
            <ArrowLeft />
            </button>
            <button
            className="border hover:bg-slate-300 transition-colors duration-900 rounded-xl px-2 py-2"
            onClick={() => handleNext("Losers")}
            >
            <ArrowRight />
            </button>
            </div>

            </div>

              <SampleCarousel data={losers} currIndex={losersIndex} onButtonClick={handleModalOpen}/>
            </div>

          </div>
        </div>
        <div className="w-full md:w-[30%] flex flex-col items-center gap-5 md:px-3 mt-5 md:mt-0">
          <div className="w-full h-48 md:h-[43vh] flex flex-col justify-start generalcard glass-effect p-2 rounded-lg shadow-lg">
            <div className="flex flex-row justify-center items-center gap-3 mb-3">
              <h1 className="text-1xl md:text-[1.5rem] font-bold">History</h1>
            </div>
            <SimpleLineChart style={{ width: "100%", height: "100%" }} />
          </div>
          <div className="w-full h-48 md:h-[45vh] flex flex-col justify-start bg-[#f5f4fa] glass-effect p-2 rounded-lg shadow-lg">
            <div className="flex flex-row justify-center items-center gap-3 mb-3">
              <h1 className="text-1xl md:text-2xl font-bold">Diversification</h1>
            </div>
            <SimplePieChart style={{ width: "100%", height: "100%" }} />
          </div>
        </div>
      </div>
      {
      modal && <BuySellModal defaultBuy={false} asset={assetname} onButtonClick={handleModalOpen}/>
      }
    </div>
  );
};

export default Portfolio;
