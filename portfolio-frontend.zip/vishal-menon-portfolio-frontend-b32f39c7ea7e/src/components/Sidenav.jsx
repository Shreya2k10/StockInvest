import React from 'react'
import { Outlet } from 'react-router-dom'
import { ChevronFirst, ChevronLast, MoreVertical, Shell } from 'lucide-react'
import { useContext, createContext, useState } from "react"
import { useNavigate } from 'react-router-dom'
import { House, Archive, ChartColumn, Store, Menu, RefreshCw} from 'lucide-react'
import BuySellModal from './BuySellModal'
import { Sell } from '@mui/icons-material'
import { DataContext } from '../context/DataContext'
import { Toaster, toast } from 'sonner'
import { WalletMinimal } from 'lucide-react'
import Wallet from '../components/Wallet'


const Sidenav = () => {

const navIconColor = '#FFFFFF'
const navigate = useNavigate();
const { forceRefresh } = useContext(DataContext);
const [openWallet, setOpenWallet] = useState(false);

  return (
    <div className='flex flex-row font-inter'>
    <Toaster richColors  toastOptions={{
    classNames: {
      toast: 'text-lg',
    },
  }}/>
    <div className='flex flex-row font-inter'>
    <div className="h-screen left-0 w-20 bg-[#2B2C43] p-4 flex flex-col"></div>
    <div className="fixed z-50 h-screen left-0 w-20 bg-[#2B2C43] p-4 flex flex-col">
        {/* <h1 className="text-slate-900 text-4xl text-center text-white font-bold my-4">
            Code Breakers 
            </h1> */}
            <button onClick={()=>{navigate("/portfolio")}} 
            className={`flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white`} >
            <Menu />
            {/* Home */}
            </button>
        <section className="flex flex-col gap-1 h-4/5 min-w-full my-2 py-5">

            <button onClick={()=>{navigate("/portfolio")}} 
            className={`flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white`} >
            <House />
            {/* Home */}
            </button>

            <button onClick={()=>{navigate("/tradehistory")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white">
            <Archive />
            {/* Transaction History */}
            </button>

            {/* <button onClick={()=>{navigate("/analysis")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <ChartColumn />
            </button> */}

            <button onClick={()=>{navigate("/market")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <Store />
            {/* Market */}
            </button>

            {/* <button onClick={()=>{navigate("/generalcard")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <Store />
            </button> */}

            {/* <button onClick={()=>{navigate("/securitiescard")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <Store />
            </button>

            <button onClick={()=>{navigate("/walletcard")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <Store />
            </button>

            <button onClick={()=>{navigate("/modal")}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <Shell />
            </button> */}
            
            <button onClick={()=>{setOpenWallet(!openWallet)}} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white">
            <WalletMinimal />
            </button>

            <button onClick={forceRefresh} className="flex flex-row justify-center gap-2 rounded-md px-2 py-3 text-white font-bold hover:bg-gray-700 hover:text-white" >
            <RefreshCw />
            </button>

        </section>
    </div>
    </div>
    <div className={`fixed z-[10] bottom-5 bg-slate-600 px-3 py-3 rounded ${openWallet ? 'left-[4.75rem]' : '-left-[25rem]'} transitions-all duration-300`}>
        <Wallet className=''/>
    </div>
    <div className='flex flex-row justify-center flex-1'>
    <Outlet/>
    </div>
    </div>
  )
}

export default Sidenav
