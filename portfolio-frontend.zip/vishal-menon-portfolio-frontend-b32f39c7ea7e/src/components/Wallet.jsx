import React, { useContext, useEffect } from 'react'
import PurpleCircle from './icons/PurpleCircle'
import WirelessIcon from './icons/WirelessIcon'
import { Copy, CirclePlus } from 'lucide-react'
import Wolf from './icons/Wolf'
import axios from '../api/axios'
import { toast } from 'sonner'
import { useState } from 'react'
import { DataContext } from '../context/DataContext'

const Wallet = () => {

  const {walletData} = useContext(DataContext)

  const [walletInput, setWalletInput] = useState();
  const [balance, setBalance] = useState(0);

  const handleWalletInputChange = (event) => {
    setWalletInput(event.target.value);
    
};

const addBalance = async () => {
  try {

      const response = await axios.post(`/balance/add/${walletInput}`)
      fetchBalance();
      toast.success('Added Balance: ' + response.data.message);
      console.log('Purchase successful:', response.data);
    } catch (error) {
      toast.error('Error');
      console.error('Error making purchase:', error.data);
    }
}

const fetchBalance = async () => {
  try {

    const response = await axios.get(`/balance`)
    console.log(response)
    setBalance(response.data.Balance)
    
    console.log('Purchase successful:', response.data);
  } catch (error) {
    console.error('Error making purchase:', error);
  }
}

useEffect(()=>{

  fetchBalance();
  
},[walletData])


  return (
    <div className=''>
    <div className='w-[21rem] h-[14rem] border bg-wallet backdrop-blur-walletblur rounded-xl shadow-generalcard3  overflow-hidden'>
        
        <div className='absolute right-7 top-[10rem]'>
        <img alt="wolf" src="/wolf.png" height={50} width={50}/>
        {/* <Wolf width={50} height={50}/> */}
        </div>
        <div className='absolute'>
            <PurpleCircle width={500} height={500}/>
        </div>
        <div className='absolute left-8 top-[1.5rem]'>
        <h1 className='font-inter font-bold text-xl text-white drop-shadow-[0_1.2px_1.2px_rgba(0,0,0,0.8)]'>Code Breakers</h1>
        </div>
        <div className='absolute right-8 top-8'>
        <WirelessIcon width={28} height={28}/>
        </div>
        <div className='absolute left-8 top-[4.5rem] flex items-center gap-3'>
        <h1 className='font-inter font-bold text-xl'>$ {balance.toFixed(2)}</h1>
        <input value={walletInput} onChange={handleWalletInputChange} className='border ml-4 w-[6rem] rounded px-1'></input>
        <CirclePlus onClick={()=>{addBalance()}} className='w-5 cursor-pointer' />
        </div>
        <div className='absolute left-8 top-[8.25rem] flex flex-row items-center gap-3'>
        <h1 className='font-inter text-xs px-2 py-2 border border-white rounded-xl'>0xcBEd...cf44Rt</h1>
        <Copy width={15}/>
        </div>
        <div className='absolute left-9 top-[11.25rem] flex flex-row items-center gap-3'>
        <h1 className='font-inter font-bold text-xs'>Steve</h1>
        <h1 className='font-inter text-xs'>--12 Aug 2024--</h1>
        </div>
        
        
    </div>
    {/* <div className='w-40 h-20 bg-wallet-rect backdrop-blur-walletrect shadow-walletrect '>
        
    </div> */}
    
    </div>
  )
}

export default Wallet