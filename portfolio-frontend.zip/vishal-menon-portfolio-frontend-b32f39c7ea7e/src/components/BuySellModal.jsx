import { X } from 'lucide-react'
import React, { useState } from 'react'
import { useLockBodyScroll } from '@uidotdev/usehooks';
import axios from '../api/axios';
import { toast } from 'sonner';

const BuySellModal = (props) => {

    const [price, setPrice] = useState(0);
    const [quantity, setQuantity] = useState(0);
    const [isBuy, setIsBuy] = useState(props.defaultBuy);

    const handleSellTab = () => {
        setIsBuy(false);
    }

    const handleBuyTab = () => {
        setIsBuy(true);
    }

    const handlePriceChange = (event) => {
        setPrice(event.target.value);
    };

    const handleQuantityChange = (event) => {
        setQuantity(event.target.value);
    };

    useLockBodyScroll();

    const closeModal = () => {
        props.onButtonClick();
        //onClick={closeModal} 
    }

    const buyAsset = async () => {
        try {

            console.log({
                assetname: props.asset.asset_name, // Assuming the property is named asset_name in the asset object
              price: props.asset.current_price, // Assuming this is the correct property for price
              quantity: parseInt(quantity),
              symbol: props.asset.ticker
            })
            

            const response = await axios.post('transactions/purchase', {
              assetname: props.asset.asset_name, // Assuming the property is named asset_name in the asset object
              price: props.asset.current_price, // Assuming this is the correct property for price
              quantity: parseInt(quantity),
              symbol: props.asset.ticker, // Assuming symbol is the correct property name
            });
            
            toast.success('Transaction successful');
          } catch (error) {
            toast.error('Transaction error');
          }finally{
            closeModal();
          }
    }

    const sellAsset = async () => {
        try {
            const response = await axios.post('transactions/sell', {
              assetname: props.asset.asset_name, // Assuming the property is named asset_name in the asset object
              price: props.asset.current_price, // Assuming this is the correct property for price
              quantity: parseInt(quantity),
              symbol: props.asset.ticker, // Assuming symbol is the correct property name
            });
        
            toast.success('Transaction successful');
          } catch (error) {
            toast.error('Transaction error');
          }finally{
            closeModal();
          }
    }

    

  return (
    <div className='fixed w-[100%] h-[100%]'>
        <div onClick={closeModal} className='fixed z-10 bg-slate-600 w-[100%] h-[100%] opacity-70'></div>
    <div className='z-20 bg-white fixed left-[37%] top-[15%] w-[27rem] h-[27rem] border shadow-generalcard3'>
        
        <div className='mx-6 my-5'>
            <div className='flex flex-row justify-between items-center'>
            <h1 className='font-bold font-inter'>Add transaction</h1>
            <X className='cursor-pointer' onClick={closeModal}/>
            </div>
        </div>
        <div className='flex flex-row justify-center items-center'>
            <div className='px-1 py-1 rounded-xl gap-1 flex flex-row justify-center items-center bg-slate-300'>
            <div onClick={handleBuyTab} className={`w-20 h-8 ${(isBuy) ? "bg-white ":"bg-slate-300"} hover:bg-slate-100 cursor-pointer flex rounded-lg text-xs font-bold justify-center items-center`}>Buy</div>
            <div onClick={handleSellTab} className={`w-20 h-8 ${(!isBuy) ? "bg-white ":"bg-slate-300"} hover:bg-slate-100 cursor-pointer flex rounded-lg text-xs font-bold justify-center items-center`}>Sell</div>
            </div>
        </div>
        <div className='mx-6 my-5 flex justify-center'>
            <div className='flex flex-row justify-evenly items-center border gap-4 px-2 py-1 rounded-2xl'>
            <h1 className='font-bold text-sm font-inter'>{props.asset.asset_name}</h1>
            <h1 className='font-bold text-sm font-inter'>{props.asset.ticker}</h1>
            </div>
        </div>
        <div className='flex justify-center gap-8'>
            <div>
            <h1 className='text-sm mb-1'>Price</h1>
            <input value={props.asset.current_price} className='border p-1 rounded w-[8rem]' type='text' disabled>
            </input>
            </div>
            <div>
            <h1 className='text-sm mb-1'>Quantity</h1>
            <input value={quantity} onChange={handleQuantityChange} className='border p-1 rounded w-[8rem]' type='text'>
            </input>
            </div>
        </div>
        <div className='flex flex-row justify-center items-center mt-5'>
            <div className='px-3 py-2 w-[18rem] rounded-xl flex flex-col justify-center bg-slate-300'>
            <h1 className='font-xs text-slate-600'>Total:</h1>
            <h1 className='font-bold text-3xl'>$ {(props.asset.current_price * quantity).toFixed(2)}</h1>
            </div>
        </div>
        <div className='flex justify-center'>
            <button onClick={(isBuy) ? buyAsset : sellAsset} className='mt-5 rounded-lg bg-[#3861fb] text-white p-3 px-20'>Proceed</button>
        </div>
    </div>
    </div>
  )
}

export default BuySellModal