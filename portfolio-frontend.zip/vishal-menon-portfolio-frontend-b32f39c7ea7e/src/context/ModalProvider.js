import React from 'react'
import { createContext } from 'react';
import { useState } from 'react';

export const ModalContext = createContext();


const ModalProvider = ({ children }) => {
  
  const [symbol, setSymbol] = useState('');
  const [openModal, setOpenModal] = useState(false);

  return (
    <ModalContext.Provider value={{ symbol, openModal, setOpenModal, setSymbol}}>
      {children}
    </ModalContext.Provider>
  );
}

export default ModalProvider