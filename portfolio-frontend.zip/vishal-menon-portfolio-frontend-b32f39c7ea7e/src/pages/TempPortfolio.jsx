import React from 'react'
import GeneralCard from '../components/GeneralCard'
import Divider from '@mui/material/Divider';
import SecuritiesCard from '../components/SecuritiesCard';
import EnhancedTable from '../components/EnhancedTable';
import Wallet from '../components/Wallet';
import Wolf from '../components/icons/Wolf';
import SimpleSlider from '../components/SimpleSlider';
import Analysis from './Analysis';
import axios from '../api/axios'

const TempPortfolio = () => {
  return (
    <div className='w-[100%] flex flex-col'>
    <div className='flex flex-row'>
    <div className='w-[100%] flex flex-row justify-center flex-wrap mt-10 mb-10 gap-10'>
      
    </div>
    </div>
    <Divider/>
    <div className='pt-5 w-full flex flex-row justify-center flex-wrap'>
    <h1 className='text-[2rem] font-bold'>Carousel</h1>
    </div>
    <Analysis/>
    <Divider/>
    <div className='flex flex-row justify-start flex-wrap items-center'>
      <div className='relative left-[9rem]'>
      <Wallet/>
      </div>
    </div>
    <Divider/>
    <div className='pt-5 w-full flex flex-row justify-center flex-wrap	'>
    <h1 className='text-[2rem] font-bold'>Holdings</h1>
    </div>
    <div className='w-full flex flex-row justify-center flex-wrap	'>

    </div>
    <Divider/>
    <div className='pt-5 w-full flex flex-row justify-center flex-wrap	'>
    <h1 className='text-[2rem] font-bold'>Top Gainers</h1>
    </div>
    <div className='w-full flex flex-row justify-center flex-wrap	'>
    <SecuritiesCard/>
    <SecuritiesCard/>
    <SecuritiesCard/>
    </div>
    <Divider/>
    <div className='pt-5 w-full flex flex-row justify-center flex-wrap	'>
    <h1 className='text-[2rem] font-bold'>Top Losers</h1>
    </div>
    <div className='w-full flex flex-row justify-center flex-wrap	'>
    <SecuritiesCard/>
    <SecuritiesCard/>
    <SecuritiesCard/>
    </div>
    <Divider/>
    <div className='px-10 pt-5 w-full flex flex-row justify-center flex-wrap	'>
    <h1 className='text-[2rem] font-bold pb-5'>Market</h1>
    <EnhancedTable/>
    </div>
    <div className='w-full flex flex-row justify-center flex-wrap	'>
    </div>
    </div>
  )
}

export default TempPortfolio