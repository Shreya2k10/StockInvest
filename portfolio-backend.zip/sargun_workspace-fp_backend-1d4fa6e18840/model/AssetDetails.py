class AssetDetails:
    def __init__(self):
        self.total_quantity = 0.0
        self.purchased_at = 0.0
        self.sold_at = 0.0
        self.profit_or_loss = 0.0
        self.current_value = 0.0 # Money possible for this symbol at this moment in market over all quantity

    def to_dict(self):
        asset_details = {
            "total_quantity": self.total_quantity,
            "purchased_at": round(self.purchased_at,2),
            "sold_at": round(self.sold_at,2),
            "profit_or_loss": round(self.profit_or_loss,2),
            "current_value": round(self.current_value,2)
        }
        return asset_details