from flask import jsonify

def set_balance(table,amount):
    try:
        record = table.select("*").execute()
        response = table.update({"balance": float(amount)}).eq("id", record.data[0]["id"]).execute()
        return jsonify({"message": 'Balance Updated Successfully'}), 200
    except Exception as exception:
        return jsonify({"error": "Internal server error"}), 500