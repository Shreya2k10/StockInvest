import React, { useContext, useEffect } from 'react'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ModalContext } from '../context/ModalProvider';

const MarketCard = (props) => {

const {setSymbol, setOpenModal} = useContext(ModalContext);
const navigate = useNavigate();
const [bgClass, setBgClass] = useState('bg-white'); // Default slate-300 color

  const goToStockDetails = (symbol) => {
    setSymbol(symbol);
    setOpenModal(true)
    //navigate(`/stockdetails?symbol=${symbol}`)
  }

  return (
    <div onClick={()=> goToStockDetails(props.asset?.ticker)} className={`cursor-pointer w-[18rem] h-[10rem] mr-5 mt-5 rounded-xl ${bgClass} border border-2 ${(parseFloat(props.asset?.change_percentage) > 0) ? 'border-[#34C759]' : 'border-red-300' }`}>
        <div className='p-5 h-full'>
            <div className='h-[70%]'>
            <img src="wolf.png"/>
            </div>
            <div>
            <div className='flex flex-row justify-between'>
            <h1 className='text-lg font-bold'>{props.asset?.ticker}</h1>
            <h1 className='text-lg font-bold'>{props.asset?.price}</h1>
            </div>
            <div className='flex flex-row justify-between'>
            <h1 className='text-sm '>{props.asset?.name}</h1>
            <h1 className='text-sm '>{props.asset?.change_percentage}%</h1>
            </div>
            </div>
        </div>
    </div>
  )
}

export default MarketCard