from service.YahooFinanceApi import YahooFinanceApiService
from flask import Blueprint , jsonify , request
from flasgger import swag_from

stock_graph_details_bp = Blueprint('stock_graph_details', __name__)

@stock_graph_details_bp.route('/charts/candlestick_chart/<string:symbol>', methods=['GET'])
@swag_from({
    'tags': ['Charts'],
    'summary': 'Get data for a candlestick chart',
    'description': 'This endpoint returns historical data for a candlestick chart.',
    'parameters': [
        {
            'name': 'symbol',
            'in': 'path',
            'type': 'string',
            'required': True,
        },
        {
            'name': 'interval',
            'in': 'query',
            'type': 'string',
            'default': '1d',
            'description': 'e.g., 1d, 1wk, 1mo'
        },
        {
            'name': 'period',
            'in': 'query',
            'type': 'string',
            'default': '1mo',
            'description': 'e.g., 1d, 1mo, 1y'
        }
    ],
    'responses': {
        '200': {
            'description': 'Candlestick chart data retrieved successfully'
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def candlestick_chart(symbol):

    interval = request.args.get('interval', '1d')
    period = request.args.get('period', '1mo')
    
    try:
        data = YahooFinanceApiService.get_candlestick_data(symbol, interval, period)
        return jsonify(data), 200
    except Exception as e:
        return jsonify({f"Failed to fetch stock data for symbol : {symbol}": str(e)}), 500