import React, { PureComponent } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useContext } from 'react';
import { DataContext } from '../context/DataContext';




const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip" style={{ backgroundColor: '#fff', border: '1px solid #ccc', padding: '10px' }}>
        <p className="label" style={{ margin: 0 }}>{`Time: ${label}`}</p>
        <p className="value" style={{ margin: 0 }}>{`Value: $${payload[0].value}`}</p>
      </div>
    );
  }

  return null;
};

const SimpleLineChart = () => {
  const { netWorthGraphData } = useContext(DataContext);
  
// Fetch data from DataContext

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        width={500}
        height={400}
        data={netWorthGraphData ? netWorthGraphData : []} // Use context data here
        margin={{
          top: 10,
          right: 20,
          left: 10,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="time" />
        <YAxis label={{ value: 'Value ($)', angle: -90, position: 'insideLeft', dx: -30, dy: 0 }}/>
        <Tooltip content={<CustomTooltip />} />
        <Area type="monotone" dataKey="value" stroke="#8884d8" fill="#8884d8" />
      </AreaChart>
    </ResponsiveContainer>
  );
};

export default SimpleLineChart;
