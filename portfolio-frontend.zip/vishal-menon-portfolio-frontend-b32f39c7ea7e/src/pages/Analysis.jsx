import React from 'react'
import MyCarousel from '../components/MyCarousel'
import SecuritiesCard from '../components/SecuritiesCard';

const Analysis = () => {
  return (
   <div>Analysis</div>
  )
}

export default Analysis