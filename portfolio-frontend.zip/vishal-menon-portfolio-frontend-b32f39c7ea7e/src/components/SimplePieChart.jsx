import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import CustomTooltip from './CustomTooltip';
import { useContext } from 'react';
import { DataContext } from '../context/DataContext';

const data = [
  { name: 'Stocks', value: 400 },
  { name: 'Crypto', value: 300 },
  { name: 'Forex', value: 300 },
  { name: 'Mutual funds', value: 200 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const SimplePieChart = () => {

  const { pieData } = useContext(DataContext);

  console.log(pieData)

  return (
    <ResponsiveContainer width="100%" height="90%">
      <PieChart>
        <Pie
          data={pieData ? pieData : []}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
          outerRadius={100}
          fill="#8884d8"
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
        {/* <Legend/> */}
      </PieChart>
    </ResponsiveContainer>
  );
};

export default SimplePieChart;