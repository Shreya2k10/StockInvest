class IndividualHoldingsResponse:
    def __init__(self):
        self.asset_name = 'Asset_Name'
        self.ticker = 'Ticker'
        self.quantity = 0
        self.average_price = 0.0
        self.current_price = 0.0
        self.total_invested = 0.0
        self.pnl_percent = 0.0

    def to_dict(self):
        holdings_response = {
            "asset_name": self.asset_name,
            "ticker": self.ticker,
            "quantity": self.quantity,
            "current_price": round(self.current_price,2),
            "average_price": round(self.average_price,2),
            "total_invested": round(self.total_invested,2),
            "pnl_percent": round(self.pnl_percent,2)
        }
        return holdings_response
