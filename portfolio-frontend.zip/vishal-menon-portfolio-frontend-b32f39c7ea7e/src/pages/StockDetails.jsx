import React, { useContext, useEffect } from 'react'
import ApexCharts from 'apexcharts'
import StockCandlestick from '../components/StockCandlestick'
import { useSearchParams } from 'react-router-dom'
import { useState } from 'react'
import axios from '../api/axios'
import { Divider } from '@mui/material'
import { ModalContext } from '../context/ModalProvider'
import { useLockBodyScroll } from '@uidotdev/usehooks';

const StockDetails = (props) => {

  const [searchParams] = useSearchParams();
  const symbol = searchParams.get('symbol');
  const { setOpenModal } = useContext(ModalContext);

  const [chartData, setChartData] = useState(null);
  const [stockData, setStockData] = useState(null);
  const [error, setError] = useState(null);

  const [intervals, setIntervals] = useState(null);
  const [periods, setPeriod] = useState(null);

  useLockBodyScroll();

  let USDollar = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  });

  useEffect(() => {
    const fetchChartData = async () => {
      try {
        const response = await axios.get(`/charts/candlestick_chart/${props.symbol}`, {
          params: {
            interval: intervals,
            period: periods,
          },
        });

        const formattedData = response.data.map(item => {
          const [day, date, month, year] = item.x.split(' ');
          const formattedDate = `${date} ${month} ${year}`;
          return {
            ...item,
            x: formattedDate,
          };
        });

        setChartData(formattedData);
      } catch (err) {
        console.error('Failed to fetch chart data:', err);
        setError(err.message || 'An error occurred');
      }
    };

    const fetchStockData = async () => {
      try {
        const response = await axios.get(`/assets/company-details/${props.symbol}`);

        setStockData(response.data)
        console.log(response.data)
      } catch (err) {
        console.error('Failed to fetch chart data:', err);
        setError(err.message || 'An error occurred');
      }
    };

    fetchStockData();
    fetchChartData();
  }, [symbol, intervals, periods]);

  return (
    <div className='fixed'>
      <div onClick={()=>{setOpenModal(false)}} className='fixed z-10 bg-slate-600 w-[100%] h-[100%] opacity-70'></div>
    <div className='fixed my-10 z-20 ml-[8rem] bg-white'>
      <div className='flex justify-center'>
      <div className='flex justify-center shadow-generalcard3'>
      <div className='w-[25rem] px-5 py-3 border'>
        <h1 className='font-bold text-3xl'>{stockData?.longName}</h1>
        <h1 className='text-xl'>{stockData?.symbol}</h1>
        <h1 className='text-xs mb-5'>{stockData?.industry}</h1>
        <Divider/>
        <h1 className='text-sm font-bold'>Market Cap:</h1>
        <h1 className='text-xl mb-5'>{USDollar.format(stockData?.marketCap)}</h1>
        <Divider/>
        <div className='flex flex-row gap-4 items-center mb-5'>
          <div>
          <h1 className='text-sm font-bold'>52 week High:</h1>
          <h1 className='text-xl'>{USDollar.format(stockData?.fiftyTwoWeekHigh)}</h1>
          </div>
          <div>
          <h1 className='text-sm font-bold'>52 week Low:</h1>
          <h1 className='text-xl'>{USDollar.format(stockData?.fiftyTwoWeekLow)}</h1>
          </div>
        </div>
        <Divider/>
        <div className='flex flex-row gap-4 items-center mb-5'>
          <div>
          <h1 className='text-sm font-bold'>Previous Close:</h1>
          <h1 className='text-xl'>{USDollar.format(stockData?.previousClose)}</h1>
          </div>
          <div>
          <h1 className='text-sm font-bold'>Opening Price:</h1>
          <h1 className='text-xl'>{USDollar.format(stockData?.open)}</h1>
          </div>
        </div>
        <Divider/>
        <div className='flex flex-row gap-4 items-center'>
          <div>
          <h1 className='text-sm font-bold'>Dividend Rate:</h1>
          <h1 className='text-xl'>{USDollar.format(stockData?.dividendRate)}</h1>
          </div>
          <div>
          <h1 className='text-sm font-bold'>Dividend Yield:</h1>
          <h1 className='text-xl'>{stockData?.dividendYield + "%"}</h1>
          </div>
        </div>
        {/* {JSON.stringify(stockData)} */}
      </div>
      <div className='w-[750px] h-[600px] border pt-5  rounded'>
        <div className='mx-5 flex gap-12'>
          <div>
            <h1 className='font-bold text-sm'>Interval</h1>
            <div>
              <button onClick={()=> {setIntervals('1d')}} className={`p-2 bg-slate-200 border ${(intervals === '1d') ? 'border-black' : '' }`}>1d</button>
              <button onClick={()=> {setIntervals('1wk')}} className={`p-2 bg-slate-200 border ${(intervals === '1wk') ? 'border-black' : '' }`}>1wk</button>
              <button onClick={()=> {setIntervals('1mo')}} className={`p-2 bg-slate-200 border ${(intervals === '1mo') ? 'border-black' : '' }`}>1mo</button>
            </div>
          </div>
          <div>
            <h1 className='font-bold text-sm'>Period</h1>
            <div>
              <button onClick={()=> {setPeriod('1d')}} className={`p-2 bg-slate-200 border ${(periods === '1d') ? 'border-black' : '' }`}>1d</button>
              <button onClick={()=> {setPeriod('1mo')}} className={`p-2 bg-slate-200 border ${(periods === '1mo') ? 'border-black' : '' }`}>1mo</button>
              <button onClick={()=> {setPeriod('1y')}} className={`p-2 bg-slate-200 border ${(periods === '1y') ? 'border-black' : '' }`}>1y</button>
            </div>
          </div>
        </div>
        <StockCandlestick data={chartData}/>
      </div>
      </div>
      </div>
    </div>
    </div>
  )
}

export default StockDetails