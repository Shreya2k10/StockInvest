import * as React from "react"
const PurpleCircle = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" {...props}>
    <g filter="url(#a)">
      <circle
        cx={40.315}
        cy={40.631}
        r={72.699}
        fill="#6D61FF"
        fillOpacity={0.5}
      />
    </g>
    <defs>
      <filter
        id="a"
        width={300.421}
        height={300.454}
        x={-41.396}
        y={-51.096}
        colorInterpolationFilters="sRGB"
        filterUnits="userSpaceOnUse"
      >
        <feFlood floodOpacity={0} result="BackgroundImageFix" />
        <feGaussianBlur in="BackgroundImageFix" stdDeviation={4.006} />
        <feComposite
          in2="SourceAlpha"
          operator="in"
          result="effect1_backgroundBlur_201_278"
        />
        <feBlend
          in="SourceGraphic"
          in2="effect1_backgroundBlur_201_278"
          result="shape"
        />
        <feColorMatrix
          in="SourceAlpha"
          result="hardAlpha"
          values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
        />
        <feOffset dy={20.028} />
        <feGaussianBlur stdDeviation={10.014} />
        <feComposite in2="hardAlpha" k2={-1} k3={1} operator="arithmetic" />
        <feColorMatrix values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.15 0" />
        <feBlend in2="shape" result="effect2_innerShadow_201_278" />
        <feColorMatrix
          in="SourceAlpha"
          result="hardAlpha"
          values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
        />
        <feOffset dy={-20.028} />
        <feGaussianBlur stdDeviation={10.014} />
        <feComposite in2="hardAlpha" k2={-1} k3={1} operator="arithmetic" />
        <feColorMatrix values="0 0 0 0 0.996078 0 0 0 0 0.317647 0 0 0 0 0.588235 0 0 0 0.15 0" />
        <feBlend
          in2="effect2_innerShadow_201_278"
          result="effect3_innerShadow_201_278"
        />
        <feGaussianBlur
          result="effect4_foregroundBlur_201_278"
          stdDeviation={0.401}
        />
      </filter>
    </defs>
  </svg>
)
export default PurpleCircle
