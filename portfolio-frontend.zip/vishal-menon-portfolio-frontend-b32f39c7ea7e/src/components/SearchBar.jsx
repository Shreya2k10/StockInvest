import React, { useState } from 'react';
import { Search } from 'lucide-react';

const SearchBar = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleInputChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSearch = () => {
    if (onSearch) {
      onSearch(searchTerm);
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="flex items-center w-full max-w-2xl mx-auto bg-white rounded-full shadow-md overflow-hidden">
      <input
        className="w-full px-4 py-2 text-gray-700 focus:outline-none"
        type="text"
        placeholder="Search..."
        value={searchTerm}
        onChange={handleInputChange}
        onKeyPress={handleKeyPress}
      />
      <button
        className="p-2 text-gray-500 hover:text-gray-700 focus:outline-none"
        onClick={handleSearch}
      >
        <Search className="w-5 h-5" />
      </button>
    </div>
  );
};

export default SearchBar;
