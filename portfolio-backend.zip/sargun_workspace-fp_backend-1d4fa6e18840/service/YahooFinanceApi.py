import yfinance as yf
from flask import jsonify

class YahooFinanceApiService:

    @staticmethod
    def get_stock_data(symbol, interval, period):
        try:
            stock = yf.Ticker(symbol)
            data = stock.history(interval=interval, period=period)
            data.reset_index(inplace=True)
            return data
        except Exception as e:
            return {'error': f"Failed to retrieve stock data: {str(e)}"}

    @staticmethod
    def get_candlestick_data(symbol, interval, period):
        try:
            data = YahooFinanceApiService.get_stock_data(symbol, interval, period)
            
            if 'error' in data:
                return data
            
            candlestick_data = []
            for index, row in data.iterrows():
                data_point = {
                    'x': row['Date'].to_pydatetime(),
                    'y': [round(row['Open'], 2), round(row['High'], 2), round(row['Low'], 2), round(row['Close'], 2)]
                }
                candlestick_data.append(data_point)
            
            return candlestick_data
        
        except Exception as e:
            return {'error': f"Failed to retrieve candlestick data: {str(e)}"}

    @staticmethod
    def get_company_details(symbol):
        try:
            stock = yf.Ticker(symbol)
            info = stock.info
            
            company_details = {
                "previousClose": round(info.get("previousClose", 0), 2),
                "open": round(info.get("open", 0), 2),
                "dayLow": round(info.get("dayLow", 0), 2),
                "dayHigh": round(info.get("dayHigh", 0), 2),
                "regularMarketPreviousClose": round(info.get("regularMarketPreviousClose", 0), 2),
                "regularMarketOpen": round(info.get("regularMarketOpen", 0), 2),
                "regularMarketDayLow": round(info.get("regularMarketDayLow", 0), 2),
                "regularMarketDayHigh": round(info.get("regularMarketDayHigh", 0), 2),
                "dividendRate": round(info.get("dividendRate", 0), 2),
                "dividendYield": round(info.get("dividendYield", 0), 2),
                "trailingPE": round(info.get("trailingPE", 0), 2),
                "forwardPE": round(info.get("forwardPE", 0), 2),
                "averageVolume": info.get("averageVolume", 0),  
                "marketCap": info.get("marketCap", 0),  
                "fiftyTwoWeekLow": round(info.get("fiftyTwoWeekLow", 0), 2),
                "fiftyTwoWeekHigh": round(info.get("fiftyTwoWeekHigh", 0), 2),
                "currency": info.get("currency"),
                "profitMargins": round(info.get("profitMargins", 0), 2),
                "exchange": info.get("exchange"),
                "symbol": info.get("symbol"),
                "longName": info.get("longName"),
                "country": info.get("country"),
                "website": info.get("website"),
                "industry": info.get("industry"),
            }
            
            return company_details
        
        except Exception as e:
            return {'error': f"Failed to retrieve company details: {str(e)}"}
