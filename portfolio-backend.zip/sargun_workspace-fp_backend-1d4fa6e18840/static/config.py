SUPABASE_URL = 'https://wnfaajxdsewenoirumtk.supabase.co'
SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InduZmFhanhkc2V3ZW5vaXJ1bXRrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjI1MjAyMzUsImV4cCI6MjAzODA5NjIzNX0.kKV49691nBBAm0voHVyaTa1ad_xSW3VxIS0HXX288X0'

TWELVEDATA_API_KEY = 'a11873a93964431d953e7a2efd699aaf'
TWELVEDATA_API_BASE_URL = 'https://api.twelvedata.com/'

FMP_API_KEY = [ 'Hnz6PQLUx1UZ07qtl6ZTntRvNGweKSFS' , 'urdngq5BALo2PoKzL2nRSPvun8Rl7ftj', 'UFonMFmn20jWfhwmDtfZIrgDUXiqFI8i' , 'IbBNuMBQitSp4I3vw8gMTF6Qu9J1Sgto', 'tSaFXKzvWxgNusji5bQLlA37JQGQNmMm' ] 
FMP_API_BASE_URL = 'https://financialmodelingprep.com/api/v3/'