import React from 'react';
import { DataContext } from '../context/DataContext';
import { useContext } from 'react';
import { type } from '@testing-library/user-event/dist/type';

const stocks = [
  { symbol: 'GOOG', name: 'Alphabet Inc.', price: '$163.84', change: '+1.92%' },
  { symbol: 'AMZN', name: 'Amazon.com, Inc.', price: '$165.80', change: '+1.86%' },
  { symbol: 'BTC', name: 'Bitcoin', price: '$60,667', change: '+5.61%' },
  { symbol: 'TSLA', name: 'Tesla, Inc.', price: '$198.84', change: '+3.69%' },
  { symbol: 'ETH', name: 'Ethereum', price: '$2,642', change: '+8.47%' },
  { symbol: 'NFLX', name: 'Netflix, Inc.', price: '$630.35', change: '+3.09%' },
  { symbol: 'AAPL', name: 'Apple Inc.', price: '$213.31', change: '+1.66%' },
  // Repeat for more stocks if necessary
];

const SlidingStocks = () => {

    const { assetData } = useContext(DataContext);

    let newStocks = []

    newStocks = Array.isArray(assetData) ? assetData.map((stock) => {

        return {
            symbol: stock.ticker,
            name: stock.name,
            price: stock.price,
            change: stock.change_percentage + "%"
        }
        
    }) : [];

  return (
    <div className="w-full overflow-hidden bg-gray-100 border border-gray-300">
      <div className="flex animate-ticker">
        {newStocks?.map((stock, index) => (
          <div
            className="flex-shrink-0 px-4 py-2 border-r border-gray-300"
            key={index}
          >
            <strong>{stock.symbol}</strong> {stock.name}{' '}
            <span className={`${(parseFloat(stock.change) > 0) ? 'text-[#34C759]' : 'text-red-300' }`}>
              {stock.price} ({stock.change})
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SlidingStocks;
