import React, { useState } from 'react';

const Carousel = ({ cards }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < cards.length - 3) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="relative w-full overflow-hidden">
      <div className="relative overflow-hidden">
        <div className="absolute top-4 right-4 flex gap-2">
          <button
            onClick={handlePrev}
            className="bg-gray-800 text-white p-2 rounded-full"
          >
            Prev
          </button>
          <button
            onClick={handleNext}
            className="bg-gray-800 text-white p-2 rounded-full"
          >
            Next
          </button>
        </div>
        <div
          className="flex transition-transform duration-500"
          style={{ transform: `translateX(-${currentIndex * (100 / 3)}%)` }}
        >
          {cards.map((card, index) => (
            <div key={index} className="flex-none w-1/3 p-2">
              {card}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Carousel;
