import React from 'react';

const Profile = () => {
  return (
    <div className="flex items-center m-4 h-5 w-30 mt-4">
      <img
        src="/steve.png"
        alt="Profile"
        className="w-16 h-16 mr-4 rounded-full"
      />
      <div className="flex flex-col">
        <div className="text-lg font-bold">Hello Steve</div>
        <div className="text-base text-gray-600">Greetings of the day!</div>
      </div>
    </div>
  );
};

export default Profile;
