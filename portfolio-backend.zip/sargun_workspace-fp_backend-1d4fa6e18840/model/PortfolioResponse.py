class PortfolioResponse:
    def __init__(self):
        self.wallet = 0.0
        self.total_invested = 0.0
        self.profit_loss = 0.0
        self.pnl_percent = 0.0
        # self.networth_percent = 0.0
        self.net_worth = 0.0

    def to_dict(self):
        portfolio_response = {
            "wallet": round(self.wallet,2),
            "total_invested": round(self.total_invested,2),
            "profit_loss": round(self.profit_loss,2),
            "pnl_percent": round(self.pnl_percent,2),
            "net_worth" : round(self.net_worth,2),
            # "networth_percent": self.networth_percent,
        }
        return portfolio_response
