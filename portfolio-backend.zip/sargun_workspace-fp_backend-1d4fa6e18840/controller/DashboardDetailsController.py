from flask import Blueprint , jsonify , request
from flasgger import swag_from
from model.PortfolioResponse import PortfolioResponse
from static.supabaseClient import supabase
from utility.HoldingsUtility import *

dashboard_details_bp = Blueprint('dashboard_details', __name__)

@dashboard_details_bp.route('/dashboard/portfolio-details', methods=['GET'])
@swag_from({
    'tags': ['Dashboard Details'],
    'summary': 'Get dashboard details',
    'description': 'This endpoint returns the user\'s dashboard details including amount invested, total profit/loss, stock-wise profit/loss, etc',
    'responses': {
        '200': {
            'description': 'Dashboard details retrieved successfully',
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def portfolio_details():
    try:
        portfolio_details = PortfolioResponse()

        # wallet
        wallet_response = supabase.table("walletbalance").select("*").execute()
        wallet = round(wallet_response.data[0]['balance'],2)
        if wallet:
            portfolio_details.wallet = wallet
        holdings_data = get_assetwise_holding_data()

        if holdings_data:
            for asset in holdings_data:
                #calculating total_invested money in all assets
                portfolio_details.total_invested += round((asset['quantity'] * asset['average_price']),2)
                #calculating networth money in all assets
                portfolio_details.net_worth += round(asset['quantity'] * asset['current_price'],2)

        #profit_loss
        portfolio_details.profit_loss = round(portfolio_details.net_worth - portfolio_details.total_invested,2)

        #profitloss_percentage
        if portfolio_details.total_invested != 0:
            portfolio_details.pnl_percent = round(portfolio_details.profit_loss * 100 /portfolio_details.total_invested,2)

        return jsonify(portfolio_details.to_dict()),200

    except Exception as e:
         return jsonify({"error": str(e)}), 500
    

@dashboard_details_bp.route('/dashboard/user-holdings', methods=['GET'])
@swag_from({
    'tags': ['Dashboard Details'],
    'summary': 'User Holdings',
    'description': 'This endpoint returns the User\'s holdings',
    'responses': {
        '200': {
            'description': 'User holdings details retrieved successfully',
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def User_holdings():
    try:
        holdings = get_assetwise_holding_data()
        
        if not holdings:
            return jsonify({
                "asset_wise": [],
                "top_gainers": [],
                "top_losers": []
            }), 200

        holdings_list = sorted(holdings, key=lambda x: x["pnl_percent"], reverse=True)
        
        top_gainers = holdings_list[:5]
        top_losers = holdings_list[-5:][::-1]

        response = {
            "asset_wise": holdings,
            "top_gainers": top_gainers,
            "top_losers": top_losers
        }
        
        return jsonify(response), 200
    except Exception as e:
        return jsonify({
            "asset_wise": [],
            "top_gainers": [],
            "top_losers": []
        }), 200




@dashboard_details_bp.route('/dashboard/networth-history', methods=['GET'])
@swag_from({
    'tags': ['Dashboard Details'],
    'summary': 'User\'s networth history',
    'description': 'This endpoint returns the User\'s networth history',
    'responses': {
        '200': {
            'description': 'Networth history retrieved successfully',
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def get_networth_history():
    try:
        history_list = list(NETWORTH_HISTORY.queue)
        return jsonify(history_list), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@dashboard_details_bp.route('/dashboard/holdings-diversification', methods=['GET'])
@swag_from({
    'tags': ['Dashboard Details'],
    'summary': 'Returns holding wise percentage',
    'description': 'This endpoint returns the user\'s holding wise percentage',
    'responses': {
        '200': {
            'description': 'holding wise percentage details retrieved successfully',
        },
        '500': {
            'description': 'Internal server error'
        }
    }
})
def holdings_diversification():
    try:
        holdings_data = get_assetwise_holding_data()
        total_invested = sum(asset['quantity']*asset['average_price'] for asset in holdings_data)
        diversification = {} 
        for asset in holdings_data:
            if total_invested > 0:
                diversification[asset['ticker']] = round((asset['quantity']*asset['average_price'] / total_invested) * 100, 2)
            else:
                diversification[asset['ticker']] = 0
        
        return jsonify(diversification), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500